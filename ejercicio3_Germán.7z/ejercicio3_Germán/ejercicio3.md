# Ejercicio 3  
![alt text](rama_creada.png)  

En esta imagen se puede ver la creacion de la rama primera con el comando git branch primera.  

![alt text](comprobacion_borrada.png)  

Aqui compruebo que se ha creado la rama primera.  

![alt text](cracion_fichero.png)  

Creo el fichero3.txt con un echo.  

![alt text](git_add_commit.png)  

Hago el git add . y el git commit -m.  

![alt text](fusion_fichero.png)  

Fusiono el fichero en la rama main.  

![alt text](eliminar_rama.png) 

Con el comando git branch -d y el nombre de la rama borro la rama primera.  

![alt text](creacion_rama2.png)  

Creo la rama segunda con el git branch segunda.  

![alt text](fichero_conflicto.png) 

Creo el fichero4.txt para que sea el fichero de conflicto.  

![alt text](duplico_fichero4.png)  

Duplico el fichero4 de la rama segunda a la rama main.  

![alt text](modifico_archivo4.png)  

Modifico el archivo en la rama main.  

![alt text](modifico_archivo4_en_segunda.png)  

Modifico el archivo de conflicto en la rama segunda.  

![alt text](conflicto.png)  

Aqui creo en conflicto.  
  
![alt text](<resolucion de conflicto.png>)  

Para solucionar el conflicto lo que hago es borrar una modificacion de un fichero de una de las ramas y hago un merge para que se duplique dicho fichero sin que de problemas.  

![alt text](conflicto_solucionado.png)  

Aqui esta la prueba de que el conflicto se ha solucionado.  
![alt text](<publicarlo en el repositorio.png>)  

Con el comando git push origin segunda publico la rama segunda en el repositorio.  

![alt text](repositorio_subido.png)  

Aqui esta la comprobacion de que la rama se ha subido al repositorio de github.




