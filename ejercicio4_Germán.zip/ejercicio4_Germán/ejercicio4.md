# Ejercicio4  
![alt text](clono_repositorio.png)  
Aqui clono el repositorio  
![alt text](rama_nueva.png)  
Creo la rama nueva  
![alt text](modifico_archivo.png)  
Creo el archivo en files y le modifico  
![alt text](<Captura de pantalla 2024-10-18 104513.png>)  
Edito el archivo radme.md y pongo la ruta de mi archivo.  
![alt text](<Captura de pantalla 2024-10-18 104810.png>)  
Subo el archivo al repositorio de github