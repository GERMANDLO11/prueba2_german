# Ejercicio1
![imagen 1](./capturas/captura1.png)  

En esta imagen creamos el repositorio local en windows.  
  
![imagen2](./capturas/captura2.png)  
En esta imagen creo dos archivos txt. 
  
![imagen3](./capturas/captura3.png)
Aqui se puede ver el repositorio creado en GitHub.  
  
![imagen4](./capturas/captura4.png)
En esta imagen me conecto con el repositorio de GitHub.  
  
![imagen5](./capturas/captura5.png)
En esta imagen utilizo este comando para mostrar las urls asocioasdas con el repositoriovinculados a mi repositorio local.  
  
![imagen6](./capturas/captura6.png)
En esta imagen clono el repositorio  
  
![imagen7](./capturas/captura7.png)
En esta imagen edito un fichero con el nano.  
  
![imagen8](./capturas/captura8.png)
En esta imagen se ve que creo el tercer archivo de texto, luego muestro con un ls los archivos y la copia del repositorio.  
  
![imagen9](./capturas/captura9.png)
En esta imagen se muestra con un git status el estado actual del repsitorio  

![imagen10](./capturas/captura10.png)
En esta imagen se puede ver como clono el repositorio en la maquina debian
![imagen11](./capturas/captura11.png)  
En esta imagen añado el cambio que le hice al fichero 2 al fichero 3  
![imagen12](./capturas/captura12.png)  
Con este comando confirmo los cambio hechos en el fichero3 
![imagen13](./capturas/captura13.png)  
Con este comando subo los cambios al repositorio remoto.
