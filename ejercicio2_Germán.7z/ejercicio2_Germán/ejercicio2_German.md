# Título Principal  
  
## Subtitulo  


Este es un parrafo donde algunas palabras estan en **negrita**, otras en *cursiva*, y aqui hay `esto esta escrito en codigo`.  

```
python  
# Este es un bloque de codigo de python  
def saludo():  
    print("¡Hola mundo!") 
```      

1. Primer elemento de la lista ordenada  
2. Segundo elemento de la lista ordenada  
3. Tercer elemento de la lista ordenada.  
  
 - Primer elemento de la lista desordenada  
 - Segundo elemento de la lista desordenada  
 - Tercer elemento de una lista desordenada  

[Enlace a una url externa](https://www.marca.com/)  

[Enlace a otro fichero Markdown](./archivo_de_prueba.md)

![imagen1](./imagenes/palmas.png)


| Encabezado 1 | Encabezado 2 | Encabezado 3 |
|--------------|--------------|--------------|
| Dato 1       | Dato 2       | Dato 3       |
| Dato 4       | Dato 5       | Dato 6       |


